# -*- coding: utf-8 -*-
"""
Created on Fri Apr 27 14:24:05 2018

@author: acer
"""
import pandas as pd

def run_formula(dv, param = None):
    def mean(df,day):
        return df.rolling(window=day,center=False).mean()  
    al46 = dv.add_formula('alpha46', 
                   "(mean(close,3)+mean(close,6)+mean(close,12)+mean(close,24))/(4*close)",
                   is_quarterly=False,
                   add_data=True,
                   register_funcs={"mean":mean})
    return al46
