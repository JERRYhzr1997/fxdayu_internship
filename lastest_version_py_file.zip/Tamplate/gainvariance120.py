# -*- coding: utf-8 -*-
"""
Created on Fri Apr 27 14:18:32 2018

@author: acer
"""
import pandas as pd

def run_formula(dv, param = None):
    def cal_positive(df):
        return df[df>0]
    pct_return = cal_positive(dv.get_ts('close').pct_change())
    inter = pd.DataFrame({name:value.dropna().rolling(120).std()**2 for name,value in pct_return.iteritems()}, index=pct_return.index).fillna(method='ffill')
    dv.append_df(inter,'gainvariance120')
    return inter
