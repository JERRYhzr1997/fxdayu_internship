# -*- coding: utf-8 -*-
"""
Created on Fri Apr 27 14:26:33 2018

@author: acer
"""
import pandas as pd

def run_formula(dv, param = None):
    def mean(df,day):
        return df.rolling(window=day,center=False).mean()  
    al85 = dv.add_formula('alpha85', 
                   "(Ts_Rank((volume / mean(volume,20)), 20) * Ts_Rank((-1 * Delta(close, 7)), 8))",
                   is_quarterly=False,
                   add_data=True,
                   register_funcs={"mean":mean})
    return al85
