# -*- coding: utf-8 -*-
"""
Created on Fri Apr 27 14:27:32 2018

@author: acer
"""
import pandas as pd
import numpy as np
import talib as ta

def run_formula(dv, param = None):
    volume=dv.get_ts("volume").dropna(axis=1)
    vema12=pd.DataFrame(index=volume.index)
    lista=list(volume.columns)
    for i in range(len(lista)):
        inter=pd.DataFrame(pd.Series(ta.EMA(np.array(list(volume[lista[i]])),12)),columns=[lista[i]])
        inter=inter.pop(lista[i])
        vema12.insert(i,lista[i],np.array(inter)) 
    temp=[]
    test=list(vema12.columns)
    for i in volume.columns:
        if i not in test:
            temp=temp+[i]
    for i in temp:
        vema12[i]=np.nan
    dv.append_df(vema12,"vema12")
    return vema12
