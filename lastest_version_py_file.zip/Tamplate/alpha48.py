# -*- coding: utf-8 -*-
"""
Created on Fri Apr 27 14:25:57 2018

@author: acer
"""
import pandas as pd

def run_formula(dv, param = None):
    def sum_fxdayu(df,day):
        return df.rolling(window=day,center=False).sum()  
    al48 = dv.add_formula('alpha48', 
                   "(-1*((Rank(((Sign((close - Delay(close, 1))) + Sign((Delay(close, 1) - Delay(close, 2)))) +Sign((Delay(close, 2) - Delay(close, 3)))))) * SUM(volume, 5)) / SUM(volume, 20))",
                   is_quarterly=False,
                   add_data=True,
                   register_funcs={"SUM":sum_fxdayu})
    return al48