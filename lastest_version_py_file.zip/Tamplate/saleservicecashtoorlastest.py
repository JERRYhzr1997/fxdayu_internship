# -*- coding: utf-8 -*-
"""
Created on Fri Apr 27 14:30:28 2018

@author: acer
"""
import pandas as pd

def run_formula(dv, param = None):
    ssctol= dv.add_formula('ssctol', 
                   "cash_recp_sg_and_rs/oper_rev",
                   is_quarterly=False,
                   add_data=True)
    return ssctol