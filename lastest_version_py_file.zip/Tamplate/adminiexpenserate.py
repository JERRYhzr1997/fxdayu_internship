# -*- coding: utf-8 -*-
"""
Created on Fri Apr 27 14:29:43 2018

@author: acer
"""
import pandas as pd

def run_formula(dv, param = None):
    ader = dv.add_formula('adminiexpenserate', 
                   "TTM(less_gerl_admin_exp)/TTM(total_oper_rev)",
                   is_quarterly=False,
                   add_data=True)
    return ader
