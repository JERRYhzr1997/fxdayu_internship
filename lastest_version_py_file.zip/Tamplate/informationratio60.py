# -*- coding: utf-8 -*-
"""
Created on Fri Apr 27 14:28:23 2018

@author: acer
"""
import pandas as pd
from jaqs_fxdayu.data.dataservice import LocalDataService


def run_formula(dv, param = None):
    dataview_folder = r'E:/data'
    ds = LocalDataService(fp = dataview_folder)
    hs300=ds.index_daily(['000300.SH'],20170101,20180101,"close")[0].pct_change()
    close=dv.get_ts("close")
    hs300=hs300.set_index(close.index)
    hs300=hs300['close']
    close=close.dropna(axis=1)
    close=close.pct_change()
    close=close.sub(hs300,axis=0)   #计算出了每日的超额收益,下面计算60日IC
    ret=close.rolling(window=60).mean()
    std=close.rolling(window=60).std()
    ir60=close.copy()
    for col in ir60.columns:
        ir60[col]=ret[col].div(std[col],axis=0)#计算出60日信息比率
    dv.append_df(ir60,"ir60")
    return ir60
